Readme File

Defined template for Animal with slots Legs, Location and Skin

Defined start up

Defined rules for every Animal with their slot and attributes

Defined rules for taking the inputs from the user and tracing it from the defined rules