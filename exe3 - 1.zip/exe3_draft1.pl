
structure(bicycle, front_wheel).
structure(bicycle, driving_handle).
structure(bicycle, middle_area).
structure(bicycle, driving_set).
structure(bicycle, back_wheel).
structure(bicycle, chain_area).


components(front_wheel, disc_break).
components(front_wheel, quick_release_skewer).
components(front_wheel, wheel_hub).
components(front_wheel, spoke).
components(front_wheel, spoke_nipple).
components(front_wheel, valve_stem).

components(driving_handle, headset).
components(driving_handle, stem).
components(driving_handle, drop_handlebar).
components(driving_handle, break_hood).
components(driving_handle, brake_shift_lever).

components(middle_area, frame).
components(middle_area, break_cable).

components(driving_set, saddle).
components(driving_set, seat_clamp).
components(driving_set, seatpost).
components(driving_set, seatpost_clamp).

components(back_wheel, calliper_brake).
components(back_wheel, gear_cable).
components(back_wheel, rear_srockets).
components(back_wheel, rear_derailleur).
components(back_wheel, rim).
components(back_wheel, tyre).

components(chain_area, front_derailleur).
components(chain_area, chain).
components(chain_area, chainrings).
components(chain_area, pedal_ceank_arm).
components(chain_area, pedal).

bike(Z,Y):- structure(bicycle,Z), components(Z,Y).